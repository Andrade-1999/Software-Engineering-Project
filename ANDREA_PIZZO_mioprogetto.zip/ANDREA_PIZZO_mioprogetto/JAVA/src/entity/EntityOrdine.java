package entity;

public class EntityOrdine {
	private float costototale;
	
public EntityOrdine(float costototale) {
	this.costototale=costototale;
}
public float getcostototale() {
	return costototale;
}
public void setcostototale(float costototale) {
	this.costototale=costototale;
}
}
